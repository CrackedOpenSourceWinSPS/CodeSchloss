#include <avr/io.h>
#include <inttypes.h>
#include <avr/pgmspace.h>
#include "LCD.h"

#define F_CPU 20000000UL //16MHz
#include <util/delay.h>

#define CMD 0
#define DATA 1

/*
	local functions
*/
/*************************************************************************
write 4 bit to LCD controller
Input:    nibble	4 bit to write to LCD
          rs     	1 (DATA): write data    
                 	0 (CMD): write instruction
Returns:  none
*************************************************************************/
void lcd_write(uint8_t nibble, uint8_t rs)
{
	if (rs)
		nibble |= (1<<LCD_RS_PIN);
	LCD_PORT = nibble|(1<<LCD_E_PIN);
	_delay_us(10);
	LCD_PORT &=~(1<<LCD_E_PIN);
	_delay_us(10);
}

/*************************************************************************
Move cursor to the start of next line or to the first line if the cursor 
is already on the last line.
*************************************************************************/
void lcd_newline(void)
{
    uint8_t newline;
	#if LCD_LINES==1
	    newline = 0;
	#elif LCD_LINES==2
	    if (lcd_pos < LCD_START_LINE2)
	        newline = LCD_START_LINE2;
	    else
	        newline = LCD_START_LINE1;
	#elif LCD_LINES==4
	    if ( lcd_pos < LCD_START_LINE3 )
	        newline = LCD_START_LINE2;
	    else if ( (lcd_pos >= LCD_START_LINE2) && (lcd_pos < LCD_START_LINE4) )
	        newline = LCD_START_LINE3;
	    else if ( (lcd_pos >= LCD_START_LINE3) && (lcd_pos < LCD_START_LINE2) )
	        newline = LCD_START_LINE4;
	    else 
	        newline = LCD_START_LINE1;
	#endif
    lcd_pos = newline;
	lcd_command((1<<LCD_DDRAM)+newline);
	_delay_us(50);

}

/*
** PUBLIC FUNCTIONS 
*/
/*************************************************************************
Send LCD controller instruction command
Input:   instruction to send to LCD controller, see HD44780 data sheet
Returns: none
*************************************************************************/
void lcd_command(uint8_t cmd)
{
    lcd_write(cmd >> 4, CMD);
	lcd_write(cmd & 0x0f, CMD);
}

/*************************************************************************
Send data byte to LCD controller 
Input:   data to send to LCD controller, see HD44780 data sheet
Returns: none
*************************************************************************/
void lcd_data(uint8_t data)
{
    lcd_write(data >> 4, DATA);
	lcd_write(data & 0x0f, DATA);
}

/*************************************************************************
Clear display and set cursor to home position
*************************************************************************/
void lcd_clrscr(void)
{
    lcd_command(1<<LCD_CLR);
	_delay_ms(2);
	lcd_pos = 0;
}

/*************************************************************************
Set cursor to home position
*************************************************************************/
void lcd_home(void)
{
    lcd_command(1<<LCD_HOME);
	_delay_ms(2);
	lcd_pos = 0;
}

/*************************************************************************
Set cursor to specified position
Input:    x  horizontal position  (0: left most position)
          y  vertical position    (0: first line)
Returns:  none
*************************************************************************/
void lcd_gotoxy(uint8_t x, uint8_t y)
{
	uint8_t start_line=0;	
	#if LCD_LINES==1
		start_line = LCD_START_LINE1;
	#elif LCD_LINES==2
    	switch (y)
		{
			case 0:
				start_line = LCD_START_LINE1;
				break;
			case 1:
				start_line = LCD_START_LINE2;
				break;
		}
	#elif LCD_LINES==4
    	switch (y)
		{
			case 0:
				start_line = LCD_START_LINE1;
				break;
			case 1:
				start_line = LCD_START_LINE2;
				break;
 			case 2:
				start_line = LCD_START_LINE3;
				break;
 			case 3:
				start_line = LCD_START_LINE4;
				break;
		}
	#endif
	lcd_pos = start_line + x;
	lcd_command((1<<LCD_DDRAM) + lcd_pos);
	_delay_us(40);
}

/*************************************************************************
Initialize display and select type of cursor 
Input:    dispAttr LCD_DISP_OFF            display off
                   LCD_DISP_ON             display on, cursor off
                   LCD_DISP_ON_CURSOR      display on, cursor on
                   LCD_DISP_CURSOR_BLINK   display on, cursor on flashing
Returns:  none
*************************************************************************/
void lcd_init(uint8_t dispAttr)
{
	LCD_DDR = 0x3F;         //Out: PIN0 to PIN5; In: PIN6, PIN7
	_delay_ms(30);
	lcd_write(3, CMD);
	_delay_ms(5);
	lcd_write(3, CMD);
	_delay_ms(5);
	lcd_write(3, CMD);
	_delay_ms(5);
	lcd_write(2, CMD);
	_delay_ms(5);
	lcd_command(LCD_FUNCTION_4BIT_2LINES);
	_delay_ms(5);
	lcd_command(LCD_DISP_OFF);
	_delay_ms(1);
    lcd_clrscr();
	lcd_command(LCD_MODE_DEFAULT); 
	_delay_ms(1);
    lcd_command(dispAttr);
	_delay_ms(1);
	lcd_pos = 0;
}

/*************************************************************************
Display character at current cursor position 
Input:    character to be displayed                                       
Returns:  none
*************************************************************************/
void lcd_putc(char c)
{
 	uint8_t pos;	

    if (c=='\n')
    	lcd_newline();
    else
    {
		pos = lcd_pos;
		#if LCD_WRAP_LINES==1
			#if LCD_LINES==1
        		if (pos == LCD_START_LINE1+LCD_DISP_LENGTH)
            		pos = LCD_START_LINE1;
			#elif LCD_LINES==2
        		if (lcd_pos == LCD_START_LINE1+LCD_DISP_LENGTH )
            		pos = LCD_START_LINE2;
       		else if (lcd_pos == LCD_START_LINE2+LCD_DISP_LENGTH )
             		pos = LCD_START_LINE1;
       		#elif LCD_LINES==4
		        if (lcd_pos == LCD_START_LINE1+LCD_DISP_LENGTH) 
            		pos = LCD_START_LINE2;
		        else if (lcd_pos == LCD_START_LINE2+LCD_DISP_LENGTH)
            		pos = LCD_START_LINE3;
		        else if (lcd_pos == LCD_START_LINE3+LCD_DISP_LENGTH) 
            		pos = LCD_START_LINE4;
		        else if (lcd_pos == LCD_START_LINE4+LCD_DISP_LENGTH) 
            		pos = LCD_START_LINE1;
			#endif
		#endif
		if (pos != lcd_pos)
		{
			lcd_pos = pos;
			lcd_command((1<<LCD_DDRAM)+pos);
			_delay_us(50);
		}
        lcd_data(c);
		_delay_us(50);
		lcd_pos++;
    }
}

/*************************************************************************
Display string without auto linefeed 
Input:    string to be displayed
Returns:  none
*************************************************************************/
void lcd_puts(const char *s)
{
    while (*s)
	{
        lcd_putc(*s);
		s++;
    }
}

/*************************************************************************
Display string without auto linefeed 
Input:    string to be displayed
Returns:  none
*************************************************************************/
void lcd_putsl(const char *s, unsigned char len)
{
 	unsigned char i;
  	for(i=0; i < len; i++)	
	{
        lcd_putc(*s);
		s++;
    }
}
/*************************************************************************
Display string from program memory without auto linefeed 
Input:     string from program memory be be displayed                                        
Returns:   none
*************************************************************************/
void lcd_puts_p(const char *progmem_s)
{
    char c;
    while(1)
	{
	 	c = pgm_read_byte(progmem_s);
        if (c == 0)
			break;
		lcd_putc(c);
		progmem_s++;
    }
}

