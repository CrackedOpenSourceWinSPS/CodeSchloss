#define F_CPU 8000000UL

#include <avr/io.h>
#include "LCD.h"
#include <util/delay.h>
#include <math.h>

#define Input_Length 4
#define Password 1234

char GetInput();
char GetInput () {

	PORTA = 0b00000001;
	
	if (PINA & (1 << PA4))
	{
		return '1';
	}
	if (PINA & (1 << PA5))
	{
		return '4';
	}
	if (PINA & (1 << PA6)) 
	{
		return '7';
	}
	if (PINA & (1 << PA7)) 
	{
		return '*';
	}
	
	PORTA = 0b00000010;
	
	if (PINA & (1 << PA4)) 
	{
		return '2';
	}
	if (PINA & (1 << PA5)) 
	{
		return '5';
	}
	if (PINA & (1 << PA6)) 
	{
		return '8';
	} 
	if (PINA & (1 << PA7)) 
	{
		return '0';
	}
	
	PORTA = 0b00000100;

	if (PINA & (1 << PA4))
	{
		return '3';
	}
	if (PINA & (1 << PA5))
	{
		return '6';
	}
	if (PINA & (1 << PA6))
	{
		return '9';
	}
	if (PINA & (1 << PA7))
	{
		return '#';
	}
	
	return 'f';
}

int GetDigit(int num, int n);
int GetDigit(int num, int n)
{
	int r;

	r = num / pow(10, n);

	r = r % 10;

	return r;
}

int main(void)
{
	DDRA = 0b00000111;
	DDRB = 0b10000000;
	PORTB = 0;
	
	lcd_init(LCD_DISP_ON);
	
	while (1) 
	{
		int code[Input_Length];
		int index = 0;
		char last = ' ';
		
		lcd_puts("Code: ");
		
		while (index < Input_Length)
		{
			char input = GetInput();
			
			if (input != 'f' && input != '*' && input != last)
			{
				last = input;
				if (input == '#') 
				{
					break;
				}
				
				code[index] = input - '0';

				index++;
				lcd_puts("*");
			}
			
			if (input == 'f')
				last = ' ';
			
			_delay_ms(50);
		}
		
		lcd_clrscr();
		
		int value = 1;
		
		for (int i = 0; i < Input_Length; i++)
		{
			if (code[i] != GetDigit(Password, Input_Length - (i + 1)))
				value = 0;
		}

		
		if (value) 
		{
			lcd_puts("Code accepted");
			PORTB = 0b10000000;
			_delay_ms(2000);
		    PORTB = 0;
		}
		else if (last != '#')
		{
			lcd_puts("Wrong code");
			_delay_ms(1000);
		}
		
		lcd_clrscr();
	}
}

